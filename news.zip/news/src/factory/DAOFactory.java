package factory;

import dao.DAO;
import dao.DAOProxy;

public class DAOFactory {

	//取得DAO接口实例
	public static DAO getIDAOInstance()throws Exception{
		return new DAOProxy();//代理 实例化
	}
	
}
