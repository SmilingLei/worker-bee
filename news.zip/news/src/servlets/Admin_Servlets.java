package servlets;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.News;

import com.jspsmart.upload.File;
import com.jspsmart.upload.SmartUpload;

import factory.DAOFactory;


@SuppressWarnings("serial")
public class Admin_Servlets extends HttpServlet{


	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		String action=request.getParameter("action");
		if(action.equals("login")){//登录
			login(request,response);
		}else if(action.equals("loginOut")){//注销
			loginOut(request,response);
		}else if(action.equals("addNews")){//添加新闻
			addNews(request,response);
		}else if(action.equals("delete")){//删除新闻
			delete(request,response);
		}else if(action.equals("update")){//修改新闻第一步，得到需要修改的新闻信息
			update(request,response);
		}else if(action.equals("update2")){//修改新闻第二步
			update2(request,response);
		}else if(action.equals("lookup")){//搜索新闻
			lookup(request,response);
		}else if(action.equals("newsInfo")){//后台查看新闻详情
			newsInfo(request,response);
		}else if(action.equals("newsInfo2")){//前台台查看新闻详情
			newsInfo2(request,response);
		}
	}
	

	//登录
	private boolean login(HttpServletRequest request, HttpServletResponse response){
		
		//得到登录页面的账号与密码
		String  account =request.getParameter("account");
		String  password =request.getParameter("password");
		System.out.println("登录的账号："+account+",登录的密码："+password);
		try {
			String passwd=DAOFactory.getIDAOInstance().searchPasswordByAdmin_Account(account);
			
			if(passwd==null){
				System.out.println("管理员账号错误！");
				request.getSession().setAttribute("loginMessage", "管理员账号错误！");
				request.getRequestDispatcher("/loginErrorMessage.jsp").forward(request, response);
				return false;
			}
			if(!passwd.equals(password)){
				System.out.println("管理员密码错误！");
				request.getSession().setAttribute("loginMessage", "管理员密码错误！");
				request.getRequestDispatcher("/loginErrorMessage.jsp").forward(request, response);
				return false;
			}
			System.out.println("登录成功！");
			request.getSession().setAttribute("admin_account", account);
			request.getRequestDispatcher("/admin_main.jsp").forward(request, response); 
			
		} catch (Exception e) {
			System.out.println("登录异常！");
			e.printStackTrace();
		}
		return true;
	}
	//注销
	private void loginOut(HttpServletRequest request, HttpServletResponse response){
		
		request.getSession().removeAttribute("admin_account");
		try {
			response.sendRedirect("admin_login.jsp");
			System.out.println("注销成功！");
		} catch (IOException e) {
			System.out.println("注销异常！");
			e.printStackTrace();
		}
	}
	//添加新闻
	private void addNews(HttpServletRequest request, HttpServletResponse response){
		
		try {
			SmartUpload su = new SmartUpload();// 创建SmartUpload对象
			su.initialize(this.getServletConfig(), request, response);// 初始化设置
			su.upload();// 将文件数据上传
			// 注意：使用SmartUpload对象获取request这句代码要放在upload()方法后面，否则拿不到数据
			File file = su.getFiles().getFile(0);// 获取第一个上传文件
			String fileName = file.getFileName();//照片名
			if(!fileName.equals("")&&fileName!=null){
				String savePath = "upload\\";
				savePath += file.getFileName();// 组装存储路径
				file.saveAs(savePath);// 将文件保存到指定位置
				// 获取文件名
				System.out.println("照片附件：" + fileName);
			}
			
			//得到网页上是信息
			String new_classify=su.getRequest().getParameter("new_classify");
			String new_title=su.getRequest().getParameter("new_title");
			String new_content=su.getRequest().getParameter("new_content");
			String new_writer=su.getRequest().getParameter("new_writer");
			
			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");//设置日期格式
			
			News news=new News();
			news.setNew_classify(new_classify);
			news.setNew_title(new_title);
			news.setNew_content(new_content);
			news.setNew_writer(new_writer);
			news.setNew_image(fileName);
			news.setNew_datetime(df.format(new Date()));
			
			if(DAOFactory.getIDAOInstance().addNews(news)){
				request.getSession().setAttribute("addNewsMessage", "新闻发布成功!");
			}else{
				request.getSession().setAttribute("addNewsMessage", "新闻发布失败!");
			}
			request.getRequestDispatcher("/addNewsMessage.jsp").forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
			request.getSession().setAttribute("addNewsMessage", "新闻发布异常!");
		}
	}
	//删除新闻
	private void delete(HttpServletRequest request, HttpServletResponse response) {
		//得到需要删除新闻的id
		int new_id=Integer.parseInt(request.getParameter("new_id"));
		try {
			if(DAOFactory.getIDAOInstance().deleteNewsByNew_id(new_id)){
				System.out.println("删除成功");
			}else{
				System.out.println("删除失败");
			}
			request.getRequestDispatcher("/admin_right.jsp").forward(request, response);
		} catch (Exception e) {
			System.out.println("删除异常");
			e.printStackTrace();
		}
	}
	//修改新闻第一步
	private void update(HttpServletRequest request, HttpServletResponse response) {
		//得到需要修改新闻的id
		int new_id=Integer.parseInt(request.getParameter("new_id"));
		
		try {
			News news=DAOFactory.getIDAOInstance().searchNewsByNew_id(new_id);
			request.getSession().setAttribute("news",news);
			request.getRequestDispatcher("/admin_updateNews.jsp").forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	//修改新闻第二步
	private void update2(HttpServletRequest request, HttpServletResponse response) {
		try {
			SmartUpload su = new SmartUpload();// 创建SmartUpload对象
			su.initialize(this.getServletConfig(), request, response);// 初始化设置
			su.upload();// 将文件数据上传
			// 注意：使用SmartUpload对象获取request这句代码要放在upload()方法后面，否则拿不到数据
			File file = su.getFiles().getFile(0);// 获取第一个上传文件
			String fileName = file.getFileName();//照片名
			if(!fileName.equals("")&&fileName!=null){
				String savePath = "upload\\";
				savePath += file.getFileName();// 组装存储路径
				file.saveAs(savePath);// 将文件保存到指定位置
				// 获取文件名
				System.out.println("照片附件：" + fileName);
			}
			System.out.println("照片附件：" + fileName);
			//得到网页上是信息
			String new_classify=su.getRequest().getParameter("new_classify");
			String new_title=su.getRequest().getParameter("new_title");
			String new_content=su.getRequest().getParameter("new_content");
			String new_writer=su.getRequest().getParameter("new_writer");
			
			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");//设置日期格式
			
			News news=new News();
			news.setNew_classify(new_classify);
			news.setNew_title(new_title);
			news.setNew_content(new_content);
			news.setNew_writer(new_writer);
			news.setNew_image(fileName);
			news.setNew_datetime(df.format(new Date()));
			int new_id=Integer.parseInt(request.getParameter("new_id"));
			
			if(DAOFactory.getIDAOInstance().updateNews(news,new_id)){
				request.getSession().setAttribute("updateNewsMessage", "新闻修改成功!");
			}else{
				request.getSession().setAttribute("updateNewsMessage", "新闻修改失败!");
			}
			request.getRequestDispatcher("/updateNewsMessage.jsp").forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
			request.getSession().setAttribute("updateNewsMessage", "新闻修改异常!");
		}
	}
	//搜索新闻
	private void lookup(HttpServletRequest request, HttpServletResponse response) {
		//获取关键字
		String keyword =request.getParameter("keyword");
		try {
			List<News> list2=DAOFactory.getIDAOInstance().searchNewsByKeyword(keyword);
			request.getSession().setAttribute("list2", list2);
			request.getRequestDispatcher("/admin_lookupNews.jsp").forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	//查看详情
	private void newsInfo(HttpServletRequest request, HttpServletResponse response) {
		int new_id=Integer.parseInt(request.getParameter("new_id"));
		System.out.println(new_id);
		
		try {
			News news = DAOFactory.getIDAOInstance().searchNewsByNew_id(new_id);
			System.out.println(news);
			request.getSession().setAttribute("news", news);
			request.getRequestDispatcher("/admin_newsInfo.jsp").forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	private void newsInfo2(HttpServletRequest request, HttpServletResponse response) {
		int new_id=Integer.parseInt(request.getParameter("new_id"));
		System.out.println(new_id);
		
		try {
			News news = DAOFactory.getIDAOInstance().searchNewsByNew_id(new_id);
			System.out.println(news);
			request.getSession().setAttribute("news2", news);
			request.getRequestDispatcher("/newsDetails.jsp").forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
