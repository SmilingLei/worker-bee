package bean;

public class News {

	private int new_id;
	private String new_classify;
	private String new_title;
	private String new_content;
	private String new_writer;
	private String new_datetime;
	private String new_image;
	
	public String getNew_image() {
		return new_image;
	}
	public void setNew_image(String new_image) {
		this.new_image = new_image;
	}
	public int getNew_id() {
		return new_id;
	}
	public void setNew_id(int new_id) {
		this.new_id = new_id;
	}
	public String getNew_classify() {
		return new_classify;
	}
	public void setNew_classify(String new_classify) {
		this.new_classify = new_classify;
	}
	public String getNew_title() {
		return new_title;
	}
	public void setNew_title(String new_title) {
		this.new_title = new_title;
	}
	public String getNew_content() {
		return new_content;
	}
	public void setNew_content(String new_content) {
		this.new_content = new_content;
	}
	public String getNew_writer() {
		return new_writer;
	}
	public void setNew_writer(String new_writer) {
		this.new_writer = new_writer;
	}
	public String getNew_datetime() {
		return new_datetime;
	}
	public void setNew_datetime(String new_datetime) {
		this.new_datetime = new_datetime;
	}
	
}
