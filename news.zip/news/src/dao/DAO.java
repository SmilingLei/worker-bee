package dao;

import java.util.List;

import bean.News;

public interface DAO {

	
	//登录验证密码
	public String searchPasswordByAdmin_Account(String Admin_Account)throws Exception;
	
	//发布新闻
	public boolean addNews(News news)throws Exception;
	
	//删除新闻
	public boolean deleteNewsByNew_id(int new_id)throws Exception;
	
	//修改新闻
	public boolean updateNews(News News,int new_id)throws Exception;
	
	//根据关键字查找新闻
	public List<News> searchNewsByKeyword(String keyword)throws Exception;
	
	//根据id查找新闻
	public News searchNewsByNew_id(int new_id) throws Exception ;
	
	//分页显示新闻 
	public List<News> goPage(int pageNow)throws Exception;
	
	//分页总页数
	public int pageAmount(String tableName) throws Exception;
	
	//显示全部图片新闻
	public List<News> showAllImageNews()throws Exception;
	
	//显示数据库最新10条记录
	public List<News> showPartNews(String type)throws Exception;
	
	
}
