package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import bean.News;

public class DAOImpl implements DAO {

	private static int pageSize = 4;// 每页显示多少条信息
	private static int showInfo = 2;//前端首页显示新闻数量
	private Connection conn; // 数据库连接对象
	private PreparedStatement pstmt; // 数据库操作对象

	public DAOImpl(Connection conn) { // 通过构造器方法取得数据库连接
		this.conn = conn;
	}

	// 登录验证密码
	public String searchPasswordByAdmin_Account(String Admin_Account)
			throws Exception {

		String password = null;
		String sql = "select admin_password from admin where admin_account=?";
		this.pstmt = this.conn.prepareStatement(sql);
		this.pstmt.setString(1, Admin_Account);
		ResultSet rs = this.pstmt.executeQuery();
		if (rs.next()) {
			password = rs.getString("admin_password");
		}
		this.pstmt.close();
		return password;
	}

	// 发布新闻
	public boolean addNews(News news) throws Exception {

		boolean flag = false;
		String sql = "insert into new(new_classify,new_title,new_content,new_writer,new_datetime,new_image) values (?,?,?,?,?,?)";
		this.pstmt = this.conn.prepareStatement(sql);
		this.pstmt.setString(1, news.getNew_classify());
		this.pstmt.setString(2, news.getNew_title());
		this.pstmt.setString(3, news.getNew_content());
		this.pstmt.setString(4, news.getNew_writer());
		this.pstmt.setString(5, news.getNew_datetime());
		this.pstmt.setString(6, news.getNew_image());
		if (this.pstmt.executeUpdate() > 0) {
			flag = true;
		} else {
			flag = false;
		}
		this.pstmt.close();
		return flag;
	}

	// 删除新闻
	public boolean deleteNewsByNew_id(int new_id) throws Exception {

		boolean flag = false;
		String sql = "delete from new where new_id=?";
		this.pstmt = this.conn.prepareStatement(sql);
		this.pstmt.setInt(1, new_id);
		if (this.pstmt.executeUpdate() > 0) {
			flag = true;
		} else {
			flag = false;
		}
		this.pstmt.close();
		return flag;
	}

	// 修改新闻
	public boolean updateNews(News news,int new_id) throws Exception {
		boolean flag = false;
		String sql = "update new set new_classify=?,new_title=?,new_content=?,new_writer=?,new_datetime=?,new_image=? where new_id=?";
		this.pstmt = this.conn.prepareStatement(sql);
		this.pstmt.setString(1, news.getNew_classify());
		this.pstmt.setString(2, news.getNew_title());
		this.pstmt.setString(3, news.getNew_content());
		this.pstmt.setString(4, news.getNew_writer());
		this.pstmt.setString(5, news.getNew_datetime());
		this.pstmt.setString(6, news.getNew_image());
		this.pstmt.setInt(7,new_id);
		if (this.pstmt.executeUpdate() > 0) {
			flag = true;
		} else {
			flag = false;
		}
		return flag;
	}

	// 根据关键字查找新闻
	public List<News> searchNewsByKeyword(String keyword) throws Exception {

		List<News> list = new ArrayList<News>();
		String sql = "select * from new where new_title like '%" + keyword
				+ "%' or new_content like '%" + keyword
				+ "%' or new_writer like '%" + keyword
				+ "%' or new_datetime like '%" + keyword + "%'";
		this.pstmt = this.conn.prepareStatement(sql);
		ResultSet rs = this.pstmt.executeQuery();
		while (rs.next()) {
			News news = new News();
			news.setNew_id(rs.getInt(1));
			news.setNew_classify(rs.getString(2));
			news.setNew_title(rs.getString(3));
			news.setNew_content(rs.getString(4));
			news.setNew_writer(rs.getString(5));
			news.setNew_datetime(rs.getString(6));
			news.setNew_image(rs.getString(7));
			list.add(news);
		}
		this.pstmt.close();
		return list;
	}
	// 根据id查找新闻
		public News searchNewsByNew_id(int new_id) throws Exception {

			String sql = "select * from new where new_id="+new_id;					
			this.pstmt = this.conn.prepareStatement(sql);
			ResultSet rs = this.pstmt.executeQuery();
			News news = null;
			if (rs.next()) {
				news=new News();
				news.setNew_id(rs.getInt(1));
				news.setNew_classify(rs.getString(2));
				news.setNew_title(rs.getString(3));
				news.setNew_content(rs.getString(4));
				news.setNew_writer(rs.getString(5));
				news.setNew_datetime(rs.getString(6));
				news.setNew_image(rs.getString(7));
			}
			this.pstmt.close();
			return news;
		}
	// 分页显示新闻
	public List<News> goPage(int pageNow) throws Exception {

		List<News> list = new ArrayList<News>();
		String sql = "select * from new";
		this.pstmt = this.conn.prepareStatement(sql);
		ResultSet rs = this.pstmt.executeQuery();
		
		if (rs.next()) {
			rs.absolute((pageNow - 1) * pageSize + 1);// 把结果集指针调整到当前页应该显示的记录的开始.
			do {
				if (list.size() >= pageSize) {
					break;
				}
				News news = new News();
				news.setNew_id(rs.getInt(1));
				news.setNew_classify(rs.getString(2));
				news.setNew_title(rs.getString(3));
				news.setNew_content(rs.getString(4));
				news.setNew_writer(rs.getString(5));
				news.setNew_datetime(rs.getString(6));
				news.setNew_image(rs.getString(7));
				list.add(news);
			} while (rs.next());
		}
		this.pstmt.close();
		return list;
	}

	//显示全部图片新闻
	public List<News> showAllImageNews() throws Exception {
		List<News> list = new ArrayList<News>();
		String sql = "select * from new where new_image!=''";
		this.pstmt = this.conn.prepareStatement(sql);
		ResultSet rs = this.pstmt.executeQuery();

		while (rs.next()){
			News news = new News();
			news.setNew_id(rs.getInt("new_id"));
			news.setNew_classify(rs.getString("new_classify"));
			news.setNew_title(rs.getString("new_title"));
			news.setNew_content(rs.getString("new_content"));
			news.setNew_writer(rs.getString("new_writer"));
			news.setNew_datetime(rs.getString("new_datetime"));
			news.setNew_image(rs.getString("new_image"));
			list.add(news);
		}

		this.pstmt.close();
		return list;
	}

	// 总页数
	public int pageAmount(String tableName) throws Exception {
		// 总行数
		int count = pageAmountRow(tableName);

		if (count % pageSize == 0) {
			return count / pageSize;
		} else {
			return (Integer) count / pageSize + 1;
		}
	}

	// 总行数
	public int pageAmountRow(String tableName) throws Exception {
		String sql = "select * from " + tableName;
		this.pstmt = this.conn.prepareStatement(sql);
		ResultSet rs = this.pstmt.executeQuery();
		rs.last();
		int rowCount = rs.getRow();
		this.pstmt.close();
		return rowCount;
	}
	//显示数据库最新10条记录
	public List<News> showPartNews(String type) throws Exception {
		
		List<News> list = new ArrayList<News>();
		String sql = "select * from new where new_classify=?";
		this.pstmt = this.conn.prepareStatement(sql);
		pstmt.setString(1, type);
		ResultSet rs = this.pstmt.executeQuery();
		while(rs.next()){
			News news = new News();
			news.setNew_id(rs.getInt(1));
			news.setNew_classify(rs.getString(2));
			news.setNew_title(rs.getString(3));
			news.setNew_content(rs.getString(4));
			news.setNew_writer(rs.getString(5));
			news.setNew_datetime(rs.getString(6));
			news.setNew_image(rs.getString(7));
			list.add(news);
			System.out.println("id="+news.getNew_id());
			System.out.println("类别="+news.getNew_classify());
			System.out.println("内容="+news.getNew_content());
		}
		this.pstmt.close();
		
		return reversal(list);
	}
	//取值list部分值并逆转list
	private List<News> reversal(List<News> list){
		List<News> temp=new ArrayList<News>();
		List<News> test=new ArrayList<News>();
		//开始下标
		try {
			int start=list.size()-showInfo;
			
			for(int i=start;i<list.size();i++){
				temp.add(list.get(i));
			}
			
			for(int i=temp.size()-1;i>=0;i--){
				test.add(temp.get(i));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return test;
	}

}
