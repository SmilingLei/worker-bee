package dao;

import java.util.List;

import bean.News;
import dbc.DatabaseConnection;

public class DAOProxy implements DAO{
	private DatabaseConnection dbc;
	private DAO dao;
	
	public DAOProxy() throws Exception{
		this.dbc=new DatabaseConnection();
		this.dao=new DAOImpl(dbc.getConnection());
	}
	//登录验证密码
	public String searchPasswordByAdmin_Account(String Admin_Account)
			throws Exception {
		String password=null;
		try {
			password=this.dao.searchPasswordByAdmin_Account(Admin_Account);
		} catch (Exception e) {
			throw e;
		}finally{
			this.dbc.close();
		}
		return password;
	}
	//发布新闻
	public boolean addNews(News news) throws Exception {
		boolean flag=false;
		try {
			flag=this.dao.addNews(news);
		} catch (Exception e) {
			throw e;
		}finally{
			this.dbc.close();
		}
		return flag;
	}
	//删除新闻

	public boolean deleteNewsByNew_id(int new_id) throws Exception {
		
		boolean flag=false;
		try {
			flag=this.dao.deleteNewsByNew_id(new_id);
		} catch (Exception e) {
			throw e;
		}finally{
			this.dbc.close();
		}
		return flag;
	}
	//修改新闻
	
	public boolean updateNews(News news,int new_id) throws Exception {
		boolean flag=false;
		try {
			flag=this.dao.updateNews(news,new_id);
		} catch (Exception e) {
			throw e;
		}finally{
			this.dbc.close();
		}
		return flag;
	}
	//根据关键字查找新闻

	public List<News> searchNewsByKeyword(String keyword) throws Exception {
		List<News> list=null;
		try {
			list=this.dao.searchNewsByKeyword(keyword);
		} catch (Exception e) {
			throw e;
		}finally{
			this.dbc.close();
		}
		return list;
	}
	//分页显示新闻 
	
	public List<News> goPage(int pageNow) throws Exception {
		List<News> list=null;
		try {
			list=this.dao.goPage(pageNow);
		} catch (Exception e) {
			throw e;
		}finally{
			this.dbc.close();
		}
		return list;
	}
	//分页总页数

	public int pageAmount(String tableName) throws Exception {
		
		int page=0;
		try {
			page=this.dao.pageAmount(tableName);
		} catch (Exception e) {
			throw e;
		}finally{
			this.dbc.close();
		}
		return page;
	}

	public List<News> showAllImageNews() throws Exception {
		List<News> list=null;
		try {
			list=this.dao.showAllImageNews();
		} catch (Exception e) {
			throw e;
		}finally{
			this.dbc.close();
		}
		return list;
	}
	
	public News searchNewsByNew_id(int new_id) throws Exception {
		News news=null;
		try {
			news=this.dao.searchNewsByNew_id(new_id);
		} catch (Exception e) {
			throw e;
		}finally{
			this.dbc.close();
		}
		return news;
	}
	//显示数据库最新10条记录
	public List<News> showPartNews(String type) throws Exception {
		List<News> list=null;
		try {
			list=this.dao.showPartNews(type);
		} catch (Exception e) {
			throw e;
		}finally{
			this.dbc.close();
		}
		return list;
	}
	
}
